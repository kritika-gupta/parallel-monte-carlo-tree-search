import os
import subprocess
import sys
#import numpy

csv_name = input("Output CSV name:")

methods = ["serial", "leaf", "root"]

if(len(sys.argv) < 3):
    print("Usage : python runner.py processors runs [verbose]")
    exit()
    
maxProc = int(sys.argv[1])
runs = int(sys.argv[2])
try:
    verbose = eval(sys.argv[3])
except:
    verbose = False

processors = range(1, maxProc+1)
#problem_size = [100*i for i in range(4, 9)]
problem_size = [500, 1000, 5000]
base = os.getcwd()

serial_file = base + "/new_c4.cpp"
leaf_file = base + "/new_c4_leaf.cpp"
root_file = base + "/new_c4_root.cpp"
serial_exec = base + "/c4"
leaf_exec = base + "/c4_leaf"
root_exec = base + "/c4_root"
os.system("g++ -g -fopenmp -std=c++11 " + serial_file + " -o " + serial_exec)
os.system("g++ -g -fopenmp -std=c++11 " + leaf_file + " -o " + leaf_exec)
os.system("g++ -g -fopenmp -std=c++11 " + root_file + " -o " + root_exec)


serial_success, leaf_success, root_success = {}, {}, {}

avg_serial_success, avg_leaf_success, avg_root_success = {}, {}, {}

serial_time, leaf_time, root_time = {}, {}, {}

avg_serial_time, avg_leaf_time, avg_root_time = {}, {}, {}

leaf_speedup, root_speedup = {}, {}

for p in processors:
    for n in problem_size:
        serial_success[(n, p)] = 0
        leaf_success[(n, p)] = 0
        root_success[(n, p)] = 0

        serial_time[(n, p)] = 0
        leaf_time[(n, p)] = 0
        root_time[(n, p)] = 0


for r in range(runs):
    if verbose:
        print("Run: ", r)
        print("-"*80)
    for p in processors:
        if verbose:
            print("Cores: ", p)
        
        for n in problem_size:
            if verbose:
                print("Problem size: ", n)

            serial_out = map(float, subprocess.check_output([serial_exec, str(n)]).split())
            if verbose:
                print("serial done")
            leaf_out = map(float, subprocess.check_output([leaf_exec, str(n/p), str(p)]).split())
            if verbose:
                print("leaf done")
            root_out = map(float, subprocess.check_output([root_exec, str(n/p), str(p)]).split())
            if verbose:
                print("root done")

            serial_result = serial_out[0]
            leaf_result = leaf_out[0]
            root_result = root_out[0]

            #print "parallel time  = ", leaf_out[1], " serial time = ", serial_out[1], "speedup = ", serial_out[1]/leaf_out[1], "\n"
            serial_time[(n, p)] += serial_out[1]
            leaf_time[(n, p)] += leaf_out[1]
            root_time[(n, p)] += root_out[1]
            
            if serial_result == 3:
                serial_success[(n, p)] += 1
            if leaf_result == 3:
                leaf_success[(n, p)] += 1
            if root_result == 3:
                root_success[(n, p)] += 1
    if(verbose):
        print("-"*80)

for p in processors:
    
    for i in problem_size:
        
        avg_serial_success[(i, p)] = (serial_success[(i, p)])/float(runs)
        avg_leaf_success[(i, p)] = (leaf_success[(i, p)])/float(runs)
        avg_root_success[(i, p)] = (root_success[(i, p)])/float(runs)

        avg_serial_time[(i, p)] = (serial_time[(i, p)])/float(runs)
        avg_leaf_time[(i, p)] = (leaf_time[(i, p)])/float(runs)
        avg_root_time[(i, p)] = (root_time[(i, p)])/float(runs)

        leaf_speedup[(i, p)] = (avg_serial_time[(i, p)])/(avg_leaf_time[(i, p)])
        root_speedup[(i, p)] = (avg_serial_time[(i, p)])/(avg_root_time[(i, p)])

        if verbose:
            print("\n\nProblem size : ", i, "cores = ", p)
            print("Avg. serial success rate : ", avg_serial_success[(i, p)])
            print("Avg. leaf success rate : ", avg_leaf_success[(i, p)])
            print("Avg. root success rate : ", avg_root_success[(i, p)])


            print("Leaf Speedup = ", leaf_speedup[(i, p)])
            print("Root Speedup = ", root_speedup[(i, p)])

         
with f as open(csv_name, "w"):
    for m in methods:
        for p in processors:
            for i in problem_size:
                if m == "serial":
                    f.write("0 , "+str(i)+", "+ str(avg_serial_time[(i, p)])+", 1, " + m)
                elif m == "leaf":
                    f.write(str(p) + ", " + str(i) + ", " + str(avg_leaf_time[(i, p)]) + ", " + str(leaf_speedup[(i, p)]) + "," + m)
                else:
                    f.write(str(p) + ", " + str(i) + ", " + str(avg_root_time[(i, p)]) + ", " + str(root_speedup[(i, p)]) + "," + m)
    f.close()

