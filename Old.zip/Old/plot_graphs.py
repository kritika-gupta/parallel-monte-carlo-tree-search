import numpy
import pylab
import sys

csv = open(sys.argv[1], "r")
prefix = input("output file prefix:\t")
info = csv.read().split("\n")


serial_time = {}
leaf_time = {}
leaf_speedup = {}
root_time = {}
root_speedup = {}
procs = []
sizes = []

for i in info:
	line = i.split(",")
	print(line)
	try:
		p = int(line[0])
		n = int(line[1])
	except:
		break
	if p:
		procs.append(p)
	sizes.append(n)
	if line[-1] == "serial":
		serial_time[(n, p)] = float(line[2])
	elif line[-1] == "leaf":
		leaf_time[(n, p)] = float(line[2])
		leaf_speedup[(n, p)] = float(line[3])
	else:
		root_time[(n, p)] = float(line[2])
		root_speedup[(n, p)] = float(line[3])

sizes = sorted(list(set(sizes)))
procs = sorted(list(set(procs)))

pylab.figure()
for i in sizes:
	pylab.plot(procs, [leaf_speedup[(i, j)] for j in procs], label = "Problem size = %d"%i)
pylab.legend(loc = "best")
pylab.grid(True)
pylab.xlabel("Number of Cores")
pylab.ylabel("Speedup")
pylab.title("Speedup vs number of cores\nfor leaf parallelization")
pylab.show()

pylab.figure()
for i in sizes:
	pylab.plot(procs, [leaf_time[(i, j)] for j in procs], label = "Problem size = %d"%i)
	pylab.plot(procs, [serial_time[(i, 0)] for j in procs], label = "Serial time for problem size = %d"%i)
pylab.legend(loc = "best")
pylab.grid(True)
pylab.xlabel("Number of Cores")
pylab.ylabel("Time (s)")
pylab.title("Time vs number of cores\nfor leaf parallelization")
pylab.show()

pylab.figure()
for i in sizes:
	pylab.plot(procs, [root_speedup[(i, j)] for j in procs], label = "Problem size = %d"%i)
pylab.legend(loc = "best")
pylab.grid(True)
pylab.xlabel("Number of Cores")
pylab.ylabel("Speedup")
pylab.title("Speedup vs number of cores\nfor root parallelization")
pylab.show()

pylab.figure()
for i in sizes:
	pylab.plot(procs, [root_time[(i, j)] for j in procs], label = "Problem size = %d"%i)
	pylab.plot(procs, [serial_time[(i, 0)] for j in procs], label = "Serial time for problem size = %d"%i)
pylab.legend(loc = "best")
pylab.grid(True)
pylab.xlabel("Number of Cores")
pylab.ylabel("Time (s)")
pylab.title("Time vs number of cores\nfor root parallelization")
pylab.show()

